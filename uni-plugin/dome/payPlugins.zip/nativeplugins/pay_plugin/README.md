# 支付插件使用说明

## 前端调用

```javascript
const plugin = uni.requireNativePlugin('testPlugin')

// 异步调用
plugin.testAsyncFunc({
  name: 'test'
}, (result) => {
  console.log(result)
})

// 同步调用
const result = plugin.testSyncFunc()
console.log(result)
```

## 导入方式

1. 将整个 my-pay-plugin 文件夹复制到 UniApp 项目的 nativeplugins 目录
2. HBuilderX 打开 manifest.json -> App原生插件配置 -> 勾选 "支付插件"
3. 重新制作自定义基座
