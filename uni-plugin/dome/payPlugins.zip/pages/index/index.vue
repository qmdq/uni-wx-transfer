<template>
	<view class="content">
		<image class="logo" src="/static/logo.png"></image>
		<view class="text-area">
			<!-- <text class="title">{{title}}</text> -->
			<button @click="test()">插件测试</button>
			<button @click="transfer()">确定转账测试</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		onLoad() {

		},
		methods: {
			transfer(){
				// 在你的 vue 页面中
				const wxTransfer = uni.requireNativePlugin('wx_transfer_uni')
				
				wxTransfer.requestMerchantTransfer(
				    'wx9336a97032b37sd2',  // appId
				    '1999394934',           // mchId  
				    'sdfsdfsdfsdfsdfpackage',    // packageInfo
				    '',          // openId，可传空字符串
				    (result) => {
				        const res = JSON.parse(result)
				        if (res.errCode === 0) {
				            console.log('请求成功')
				        } else {
				            console.log('失败:', res.errMsg)
				        }
				    }
				)

				
				
			},
		  test() {
		      const pluginImpl = uni.requireNativePlugin("pay_plugin_uni")
		      const json = {
		          name: "test"
		      }
		      pluginImpl.testAsyncFunc(json, (ret) => {  // 直接传对象，不用 stringify
		          console.log(ret)
		      })
		  }

		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
